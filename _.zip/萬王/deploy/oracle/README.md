# 萬王之王 Online → Oracle Cloud Always Free（固定 IP）部署

> 這些腳本已準備好，**尚未執行**。VM 開好後照下面做即可。

## 0. 建立 VM（OCI 主控台）
1. Compute → Instances → Create instance
   - Image：**Canonical Ubuntu 24.04**（或 22.04）
   - Shape：建議 **VM.Standard.A1.Flex（ARM，Always Free 最多 4 OCPU / 24 GB）**，例如 2 OCPU / 12 GB。
     `VM.Standard.E2.1.Micro`（1 GB RAM）也能跑伺服器，但 AI 玩家（headless Chromium）會很吃緊 → 建議 `NO_BOTS=1` 或少量 AI。
   - Networking：Assign a **public IPv4**。若要「固定 IP」：Networking → IP Management → Reserved Public IPs 建立後，綁到 VM 的 VNIC（免費 1 個）。
   - 上傳／下載 SSH 金鑰（例如存成 `~/.ssh/oci.key`，`chmod 600`）。
2. **開放連接埠（Security List）**：Networking → Virtual Cloud Networks → 你的 VCN → Security Lists → Default →
   Add Ingress Rules：
   | Source CIDR | Protocol | Dest. Port |
   |---|---|---|
   | 0.0.0.0/0 | TCP | 80 |
   | 0.0.0.0/0 | TCP | 443 |
   （VM 內的 iptables 由 install.sh 自動開；兩邊都要開才連得到。）

## 1. 一鍵部署（在目前這台 box 執行）
```bash
cd /workspace/萬王之王/deploy/oracle
./push.sh ubuntu@<VM公用IP> ~/.ssh/oci.key
```
它會：打包（`pack.sh`：index.html、圖示、server、AI 程式、**data/db.json**、AI 帳密）→ scp 上傳 → 在 VM 上 `sudo install.sh`：
- 安裝 Node.js 20、（記憶體 < 3 GB 時）2 GB swap
- 程式放到 `/opt/wzw`，使用者 `wzw`，`npm ci`
- systemd：`wzw-server`（127.0.0.1:8770，自動重啟）、`wzw-aibots`（headless Chromium，由 playwright-core 下載，amd64/arm64 都可）
- **Caddy** 反向代理＋自動 HTTPS：`https://<IP用-連接>.sslip.io/`（例：IP 1.2.3.4 → `https://1-2-3-4.sslip.io/`）；也可 `http://<IP>/`
- iptables 開 80/443（Oracle Linux 則用 firewalld）並保存
- 每日備份 `db.json` 到 `/opt/wzw/backups/`（保留 14 天）

完成後畫面會印出遊戲網址。自訂網域：DNS A 記錄指到 VM IP 後 `DOMAIN=game.example.com ./push.sh ...`。

## 2. 之後更新程式（保留 VM 上的玩家資料）
```bash
NO_DATA=1 ./push.sh ubuntu@<IP> ~/.ssh/oci.key
```
install.sh 每次都會先把 VM 上的 db.json 備份成 `db.json.bak-時間`，且**不會覆蓋**既有資料（除非 `FORCE_DATA=1`）。

> 搬家當下：box 這邊在打包前先 `server/aibots.sh stop`（避免最後幾分鐘的進度沒搬到），搬完確認 VM 正常後再關掉 box 上的伺服器／通道。

## 3. VM 上常用指令
```bash
sudo systemctl status wzw-server wzw-aibots caddy
sudo journalctl -u wzw-server -f          # 伺服器 log
sudo systemctl restart wzw-server         # 重啟（SIGTERM 會先存檔）
sudo systemctl stop wzw-aibots            # 暫停 AI 玩家
ls /opt/wzw/backups/                      # 每日備份
```

## 檔案
- `pack.sh`：在 box 打包到 `dist/`（含玩家資料，dist/ 權限 700，勿外流）
- `push.sh`：打包＋上傳＋遠端安裝
- `install.sh`：VM 端安裝（可重複執行）
